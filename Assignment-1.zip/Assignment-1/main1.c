/*
 * File:   main1.c
 * Author: Lakshminarayana
 *
 * Created on 27 June, 2024, 3:47 PM
 */



#include <xc.h>
#include "main.h"
#pragma config WDTE = OFF    // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    //write initialization code here
    LED_ARRAY_DDR=0x00;
    LED_ARRAY=0x00;


}

void main(void)
{
    init_config();                          // calling the function
    unsigned int delay=0;                    // initialising variables
    int i=0;
    while(1)                                // using super loop
    {
        if(delay++ == 10000)                 // for delay
        {
            if(i<8)                         // condition checking
            {
                LED_ARRAY=(LED_ARRAY<<1) | (0x01);       //assign the values for portb
                i++;                        // increment i
            }
            else if(i>=8 && i<16)           // condition checking
            {
                LED_ARRAY=LED_ARRAY<<1;
                i++;                        // increment i
            }
            else if(i>=16 && i<24)
            {
                LED_ARRAY=(LED_ARRAY>>1) | (0x80);
                i++;
            }
            else if(i>=24 && i<32)
            {
                LED_ARRAY=LED_ARRAY>>1;
                i++;
            }
            else 
            {
                i=0;                        // assigning i as 0
            }
        }
    }
    return;
    
}