/*
 * File:   newmain.c
 * Author: laksh
 *
 * Created on 25 June, 2024, 1:06 PM
 */


#include <xc.h>

void main(void) {
    return;
}
