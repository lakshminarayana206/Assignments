/* 
 * File:   main1.h
 * Author: laksh
 *
 * Created on 27 June, 2024, 4:34 PM
 */

#ifndef MAIN1_H
#define	MAIN1_H

#define LED_ARRAY         PORTB
#define LED_ARRAY_DDR     TRISB

#endif	/* MAIN1_H */

